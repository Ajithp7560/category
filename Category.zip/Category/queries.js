


// Queries for Books ==========================================================================
const getAllbooks="select * from book_details";

// const getbookbyid="select * from book_details where book_id=$1;";
//  const  checkbookexist="select book_name from book_details  where  book_name=$1";
const  addmaincategory="insert into main_category(main_category_name,category_url)  values($1,$2)";

const addsubcategory="insert into nested_sub_category(sub_category_name, main_cat_id, category_url)  values($1,$2,$3)";

const getmaincategoryname="select * from main_category where main_categoryid=$1";

const getsubcategoryname="select * from nested_sub_category where sub_categoryid=$1";


const addproduct="insert into products(main_cat_id,product_name,sub_cat_id,category_url)  values($1,$2,$3,$4)";


//  const deleteBookbyId ="delete from book_details where book_id=$1";
//  const updateBookdetails="update book_details set book_name=$1 ,book_author=$2,book_description=$3,user_id=$4 where book_id=$5";

const updatemainproduct='update main_category set  main_category_name=$1,category_url=$2 where main_categoryid=$3';

const getsuburl="select * from nested_sub_category where main_cat_id=$1 ";

const getprodurl="select * from products where main_cat_id=$1 ";
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++






//Queries for user ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++














module.exports={
   
      addmaincategory,
      getmaincategoryname,
      addsubcategory,
      addproduct,
      getsubcategoryname,
      updatemainproduct,
      getsuburl,
      getprodurl

};


    