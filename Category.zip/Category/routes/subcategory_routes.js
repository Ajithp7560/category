const {Router} = require ("express");

const router = Router();
const controller = require("../controller/subcategory_controller")

// router.get("/id/:pro_id", controller.getProductsById);
 router.post("/",controller.addsubcategory);
// router.put('/:pro_id',controller.updateproduct);



module.exports = router;
