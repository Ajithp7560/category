const {Router} = require ("express");

const router = Router();
const controller = require("../controller/maincategory_controller")

// router.get("/id/:pro_id", controller.getProductsById);
router.post("/",controller.addmaincategory);
router.put('/:main_cat_id',controller.updatemaincategory);



module.exports = router;
