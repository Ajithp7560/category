const {Router} = require ("express");

const router = Router();
const controller = require("../controller/product_controller")


// router.get("/id/:pro_id", controller.getProductsById);
router.post("/",controller.addProduct);
// router.put('/:pro_id',controller.updateproduct);



module.exports = router;
