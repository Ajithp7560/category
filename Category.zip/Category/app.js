const express = require("express");
const app = express();
const port = 5700;
const dotenv = require("dotenv");

const {
    pool
} = require("./dbconfig");
const {
    json
} = require("express");


const maincategory = require("./routes/maincategory_routes.js")
const subcategory = require("./routes/subcategory_routes.js")
const product = require("./routes/product_routes.js")
console.log('sas')

// require("dotenv").config({ path: './config.env'});
dotenv.config({
    path: './config.env'
});

app.use(express.urlencoded({
    extended: false
}));
app.use(express.json());

// app.use(require('./routes/userroutes.js'));

app.use("/api/v1/maincategory",maincategory )
app.use("/api/v1/subcategory",subcategory)
app.use("/api/v1/product",product)



app.listen(port, () => {
    console.log(`Connection successful is at port ${port}`);
})