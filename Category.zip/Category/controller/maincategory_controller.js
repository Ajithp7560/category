const pool = require("../dbconfig")

const queries = require("../queries.js");


// const getProductsById = (req, res) => {
//     const pro_id = parseInt(req.params.pro_id);
//     pool.query(queries.getProductsById, [pro_id], (error, results) => {
//         if (!results.rows.length) {
//             res.send("product Does not exist")
//         } else {
//             res.send(results.rows);
//             console.log(results);
//         }

//     })
// }


const  addmaincategory = (req, res) => {
    let {
      main_category_name
    } = req.body;

  
    category_url='https://Catagories/'+main_category_name;
            pool.query(queries.addmaincategory, [main_category_name, category_url], (error, results) => {


                if(results){
                res.send("Main Category added successfully")
                }
                else{
                console.log(error);
                }
            })
        
 
    // console.log("insert into products (product_name, price,product_details)  values("+ product_name +" ,  "+ price +" , "+ product_details + ");");





}


const updatemaincategory = (req, res) => {

    let main_cat_id = parseInt(req.params.main_cat_id);
    const {
        main_category_name
    } = req.body;
    pool.query(queries.getmaincategoryname, [main_cat_id], (error, results) => {
        if (!results.rows.length) {
            res.send("main category Does not exist")
        } else {

            var category_url=results.rows[0].category_url;
             
            var category_url='https://Catagories/'+main_category_name;

            pool.query(queries.updatemainproduct, [ main_category_name,category_url,main_cat_id], (error, results) => {

                if (error) 
                {
                  comsole.log(error);
                }
                else{
                res.send("Main Category Updated  successfully");
                }
            })
            

        }
    });

}

module.exports = {
    addmaincategory,
    updatemaincategory

}