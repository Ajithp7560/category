const pool = require("../dbconfig")

const queries = require("../queries.js");




const addProduct = (req, res) => {
    let {
        main_cat_id,
        product_name,
        sub_cat_id
     
    } = req.body;

    pool.query(queries.getmaincategoryname, [main_cat_id], (error, results) => {

        var main_cat_name=results.rows[0].main_category_name;
        pool.query(queries.getsubcategoryname, [sub_cat_id], (error, results) => {
     
      
            var sub_cat_name=results.rows[0].sub_category_name;
    
    category_url='https://Catagories/'+main_cat_name+'/'+sub_cat_name+'/'+ product_name;
            pool.query(queries.addproduct,[main_cat_id,product_name,sub_cat_id,category_url], (error, results) => {


                if(results){
                res.send("Products added successfully")
                }
                else{
                console.log(error);
                }
            })
        
        })

    })
    // console.log("insert into products (product_name, price,product_details)  values("+ product_name +" ,  "+ price +" , "+ product_details + ");");





}


const updateproduct = (req, res) => {

    let pro_id = parseInt(req.params.pro_id);
    const {
        product_name,
        price,
        product_details
    } = req.body;
    pool.query(queries.getProductsById, [pro_id], (error, results) => {
        if (!results.rows.length) {
            res.send("Product Does not exist")
        } else {
            pool.query(queries.updateproduct, [product_name, price, product_details, pro_id], (error, results) => {
                if (error) 
                {
                  comsole.log(error);
                }
                else{
                res.send("Product Updated  successfully");
                }
            })
        }
    });

}

module.exports = {
    addProduct,
    updateproduct

}